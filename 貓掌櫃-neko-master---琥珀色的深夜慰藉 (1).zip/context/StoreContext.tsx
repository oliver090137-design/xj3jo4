
import React, { createContext, useContext, useState, useEffect } from 'react';

// --- Types ---
export interface Product {
  id: string;
  title: string;
  price: number;
  rating: number;
  image: string;
  description: string;
  tag?: string;
  category: string;
}

export interface CartItem {
  productId: string;
  title: string;
  price: number;
  image: string;
  size: string;
  quantity: number;
}

export interface OrderData {
  customerName: string;
  customerPhone: string;
  address: string;
  items: CartItem[];
  total: number;
}

interface StoreContextType {
  products: Product[];
  cart: CartItem[];
  addProduct: (product: Product) => void;
  updateProduct: (id: string, updates: Partial<Product>) => void;
  deleteProduct: (id: string) => void;
  addToCart: (item: CartItem) => void;
  removeFromCart: (productId: string, size: string) => void;
  clearCart: () => void;
  submitOrderToGoogleSheets: (data: OrderData) => Promise<boolean>;
}

// --- Initial Data ---
const INITIAL_PRODUCTS: Product[] = [
  {
    id: '1',
    title: '琥珀豬腱心',
    price: 580,
    rating: 482,
    image: 'https://lh3.googleusercontent.com/aida-public/AB6AXuCkCGEphu3VXt8gTjvqOAXEpRWyk7FopK6Hgkg_gaoiyWSiVZ2_lHyONfJnVHs5EAyARaaTpqiy7pOFcCiHAyjGyHAgZ1-ryzr-TfpGllhVD98YRJ301zTTD5d5jlYsCn9arHaPTLPbdyMm8hBqOBnUM6NyBs0xIrfxQLTu7aXqqnUqeFiH_OacYcMsELtbD4VajiTipaMA545EkS86c1pvZub6D10P4mEvL2TXf5SUDblrfZ0s-m78n7o-xn8KW_nkNTKvduUtdSE',
    description: '職人手作豬腱心，採用貓掌櫃傳承 12 小時「深夜琥珀」密製滷汁，低溫慢火入味。',
    tag: '人氣首選',
    category: 'classic'
  },
  {
    id: '2',
    title: '黑金雞腿排',
    price: 380,
    rating: 156,
    image: 'https://lh3.googleusercontent.com/aida-public/AB6AXuDk-yf0gR2D1XrWGSsTQN_gdC2d4hkGGvok5_mXT43eUj1-QMF084-4GP3ySuT9Gvizr1RwnkTEuKgq3PGRWEO2t3FA0nYNrQN1AgZ7zGD1RAzkowwP2UmqRQPS96gOynUDLyK8vAKDpRbn2TSsgZjfhMGMKiY6TsQtVSTxq_y05teBXDQIrUByRBNYzwomlY22nnugZ9QigJ5KbilFlkq-SMQNWHStV8UhZVOTuawO1L8jAvn2Drt9hoB-gYPqQsxxEuOdopcY3UE',
    description: '嚴選本土黑羽土雞，肉質鮮嫩多汁，搭配獨門黑金醬汁，香氣逼人。',
    category: 'classic'
  },
  {
    id: '3',
    title: '職人豆干',
    price: 180,
    rating: 293,
    image: 'https://lh3.googleusercontent.com/aida-public/AB6AXuBRegSGoAj2A_IMkjJTFMMd0hCYtfN-jhZFxo8HJKrNQbs0nCgkvt0mG0fyKLv5DluZ5Cj4Hq8ztBpHOPy5j2PUHGF0h3fMeTb-yYEyCkOqzB3Ghdql_WJ6YxLYR61ASiVM60E6TIhYidSKkrcBZVm5Y4UICu1l_xibWX7GPczOCanuRbnS27WkZCBEHcNbytW8sdhYF8KCpxlB0NeDulHRJJ5wwUlztQ7ayxmxNdwdEdW7f8XHQyOq48LX4OVB416HFUXiSTUUaVI',
    description: '非基改黃豆製作，口感紮實，吸滿滷汁精華，一口咬下爆漿滿足。',
    category: 'classic'
  },
  {
    id: '4',
    title: '黃金滷鵪鶉蛋',
    price: 45,
    rating: 120,
    image: 'https://picsum.photos/400/533?random=5',
    description: '小巧可愛，入味十足，是追劇下酒的最佳良伴。',
    category: 'side'
  },
  {
    id: '5',
    title: '絲路滷牛筋',
    price: 120,
    rating: 88,
    image: 'https://picsum.photos/400/533?random=7',
    description: '晶瑩剔透，Q彈有勁，富含膠原蛋白。',
    category: 'side'
  }
];

const StoreContext = createContext<StoreContextType | undefined>(undefined);

export const StoreProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [products, setProducts] = useState<Product[]>(INITIAL_PRODUCTS);
  const [cart, setCart] = useState<CartItem[]>([]);

  // Load from local storage on mount (Simulation of backend persistence)
  useEffect(() => {
    const savedProducts = localStorage.getItem('neko_products');
    if (savedProducts) {
      setProducts(JSON.parse(savedProducts));
    }
  }, []);

  // Save to local storage whenever products change
  useEffect(() => {
    localStorage.setItem('neko_products', JSON.stringify(products));
  }, [products]);

  const addProduct = (product: Product) => {
    setProducts(prev => [...prev, product]);
  };

  const updateProduct = (id: string, updates: Partial<Product>) => {
    setProducts(prev => prev.map(p => p.id === id ? { ...p, ...updates } : p));
  };

  const deleteProduct = (id: string) => {
    setProducts(prev => prev.filter(p => p.id !== id));
  };

  const addToCart = (item: CartItem) => {
    setCart(prev => {
      const existing = prev.find(i => i.productId === item.productId && i.size === item.size);
      if (existing) {
        return prev.map(i => i.productId === item.productId && i.size === item.size 
          ? { ...i, quantity: i.quantity + item.quantity } 
          : i
        );
      }
      return [...prev, item];
    });
  };

  const removeFromCart = (productId: string, size: string) => {
    setCart(prev => prev.filter(i => !(i.productId === productId && i.size === size)));
  };

  const clearCart = () => setCart([]);

  // --- GOOGLE SHEETS / FORM INTEGRATION ---
  const submitOrderToGoogleSheets = async (data: OrderData): Promise<boolean> => {
    try {
      console.log("Preparing to send order to Google Sheets:", data);
      
      // INSTRUCTIONS FOR USER:
      // 1. Create a Google Form with fields: Name, Phone, Address, Order Details, Total Price.
      // 2. Get the "pre-filled link" to find the entry IDs (e.g., entry.1234567890).
      // 3. Replace 'YOUR_GOOGLE_FORM_ACTION_URL' with the form action URL (ends in /formResponse).
      // 4. Update the 'entry.xxxxx' keys below to match your form's field IDs.
      
      /* 
      const GOOGLE_FORM_URL = "https://docs.google.com/forms/u/0/d/e/YOUR_FORM_ID/formResponse";
      const formData = new FormData();
      formData.append("entry.11111111", data.customerName);
      formData.append("entry.22222222", data.customerPhone);
      formData.append("entry.33333333", data.address);
      formData.append("entry.44444444", JSON.stringify(data.items.map(i => `${i.title} x${i.quantity}`)));
      formData.append("entry.55555555", data.total.toString());
      
      await fetch(GOOGLE_FORM_URL, {
        method: 'POST',
        body: formData,
        mode: 'no-cors' // Important for Google Forms
      });
      */

      // Simulation for now
      await new Promise(resolve => setTimeout(resolve, 1500));
      return true;
    } catch (error) {
      console.error("Order submission failed:", error);
      return false;
    }
  };

  return (
    <StoreContext.Provider value={{
      products,
      cart,
      addProduct,
      updateProduct,
      deleteProduct,
      addToCart,
      removeFromCart,
      clearCart,
      submitOrderToGoogleSheets
    }}>
      {children}
    </StoreContext.Provider>
  );
};

export const useStore = () => {
  const context = useContext(StoreContext);
  if (!context) throw new Error("useStore must be used within StoreProvider");
  return context;
};
