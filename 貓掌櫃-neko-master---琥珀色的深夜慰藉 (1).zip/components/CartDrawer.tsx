
import React, { useState } from 'react';
import { useStore, CartItem } from '../context/StoreContext';

interface CartDrawerProps {
  isOpen: boolean;
  onClose: () => void;
}

const CartDrawer: React.FC<CartDrawerProps> = ({ isOpen, onClose }) => {
  const { cart, removeFromCart, clearCart, submitOrderToGoogleSheets } = useStore();
  const [step, setStep] = useState<'cart' | 'checkout' | 'success'>('cart');
  const [loading, setLoading] = useState(false);
  
  const [customer, setCustomer] = useState({
    name: '',
    phone: '',
    address: ''
  });

  const total = cart.reduce((sum, item) => sum + (item.price * item.quantity), 0);

  const handleSubmit = async () => {
    if (!customer.name || !customer.phone) {
      alert('請填寫姓名與電話');
      return;
    }
    
    setLoading(true);
    const success = await submitOrderToGoogleSheets({
      customerName: customer.name,
      customerPhone: customer.phone,
      address: customer.address,
      items: cart,
      total
    });
    setLoading(false);
    
    if (success) {
      setStep('success');
      clearCart();
    } else {
      alert('訂單送出失敗，請稍後再試');
    }
  };

  return (
    <>
      {/* Backdrop */}
      <div 
        className={`fixed inset-0 bg-black/60 backdrop-blur-sm z-[60] transition-opacity duration-300 ${isOpen ? 'opacity-100' : 'opacity-0 pointer-events-none'}`}
        onClick={onClose}
      />
      
      {/* Drawer */}
      <div className={`fixed top-0 right-0 h-full w-full sm:w-[400px] bg-[#1a1a1a] border-l border-primary/20 z-[70] transition-transform duration-300 transform ${isOpen ? 'translate-x-0' : 'translate-x-full'} shadow-2xl flex flex-col`}>
        
        {/* Header */}
        <div className="p-6 border-b border-white/10 flex items-center justify-between bg-ink-black/50">
          <h2 className="font-calligraphy text-2xl text-primary">
            {step === 'cart' ? '您的購物車' : step === 'checkout' ? '結帳資訊' : '訂購完成'}
          </h2>
          <button onClick={onClose} className="text-gray-400 hover:text-white">
            <span className="material-symbols-outlined">close</span>
          </button>
        </div>

        {/* Content */}
        <div className="flex-1 overflow-y-auto p-6">
          {step === 'cart' && (
            <>
              {cart.length === 0 ? (
                <div className="h-full flex flex-col items-center justify-center text-gray-500 gap-4">
                  <span className="material-symbols-outlined text-6xl opacity-20">shopping_basket</span>
                  <p>購物車是空的</p>
                  <button onClick={onClose} className="text-primary underline underline-offset-4">去逛逛</button>
                </div>
              ) : (
                <div className="space-y-6">
                  {cart.map((item, idx) => (
                    <div key={`${item.productId}-${item.size}-${idx}`} className="flex gap-4">
                      <div className="size-20 rounded bg-white/5 overflow-hidden shrink-0 border border-white/10">
                        <img src={item.image} alt={item.title} className="w-full h-full object-cover" />
                      </div>
                      <div className="flex-1">
                        <div className="flex justify-between items-start">
                          <h4 className="font-bold text-white">{item.title}</h4>
                          <button 
                            onClick={() => removeFromCart(item.productId, item.size)}
                            className="text-gray-500 hover:text-red-400"
                          >
                            <span className="material-symbols-outlined text-sm">delete</span>
                          </button>
                        </div>
                        <p className="text-xs text-gray-400 mb-2">{item.size === 'single' ? '單包裝' : item.size === 'family' ? '家庭包' : '囤貨包'}</p>
                        <div className="flex justify-between items-center">
                          <span className="text-sm">x {item.quantity}</span>
                          <span className="text-primary font-bold">NT$ {item.price * item.quantity}</span>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </>
          )}

          {step === 'checkout' && (
            <div className="space-y-6">
              <div className="bg-primary/10 border border-primary/20 p-4 rounded text-sm text-primary/80">
                <p className="font-bold mb-1">📝 訂單將送至 Google Sheets</p>
                <p className="text-xs">請填寫正確資訊以方便我們為您出貨。</p>
              </div>
              <div className="space-y-4">
                <div>
                  <label className="block text-xs text-gray-400 mb-1">姓名 *</label>
                  <input 
                    value={customer.name}
                    onChange={e => setCustomer({...customer, name: e.target.value})}
                    placeholder="請輸入姓名"
                    className="w-full bg-white/5 border border-white/10 rounded px-4 py-3 text-white focus:border-primary outline-none"
                  />
                </div>
                <div>
                  <label className="block text-xs text-gray-400 mb-1">電話 *</label>
                  <input 
                    value={customer.phone}
                    onChange={e => setCustomer({...customer, phone: e.target.value})}
                    placeholder="09xx-xxx-xxx"
                    className="w-full bg-white/5 border border-white/10 rounded px-4 py-3 text-white focus:border-primary outline-none"
                  />
                </div>
                <div>
                  <label className="block text-xs text-gray-400 mb-1">收件地址</label>
                  <textarea 
                    value={customer.address}
                    onChange={e => setCustomer({...customer, address: e.target.value})}
                    placeholder="請輸入完整地址 (選填)"
                    rows={3}
                    className="w-full bg-white/5 border border-white/10 rounded px-4 py-3 text-white focus:border-primary outline-none"
                  />
                </div>
              </div>
            </div>
          )}

          {step === 'success' && (
            <div className="h-full flex flex-col items-center justify-center text-center">
              <div className="size-20 rounded-full bg-green-500/20 text-green-500 flex items-center justify-center mb-6">
                <span className="material-symbols-outlined text-4xl">check</span>
              </div>
              <h3 className="text-2xl font-bold text-white mb-2">訂購成功！</h3>
              <p className="text-gray-400 mb-8">您的訂單已傳送給貓掌櫃。<br/>我們將盡快與您聯繫確認。</p>
              <button 
                onClick={() => { setStep('cart'); onClose(); }}
                className="bg-white/10 text-white px-8 py-3 rounded-full hover:bg-white/20 transition-all"
              >
                繼續購物
              </button>
            </div>
          )}
        </div>

        {/* Footer */}
        {step !== 'success' && cart.length > 0 && (
          <div className="p-6 border-t border-white/10 bg-ink-black/50">
            <div className="flex justify-between items-center mb-6">
              <span className="text-gray-400">總計</span>
              <span className="text-2xl font-bold text-primary font-brand">NT$ {total}</span>
            </div>
            {step === 'cart' ? (
              <button 
                onClick={() => setStep('checkout')}
                className="w-full bg-gradient-to-r from-primary to-[#b88a56] text-background-dark font-bold py-4 rounded-lg hover:brightness-110 transition-all shadow-lg shadow-primary/20"
              >
                前往結帳
              </button>
            ) : (
              <div className="flex gap-3">
                <button 
                  onClick={() => setStep('cart')}
                  className="flex-1 bg-white/10 text-white font-bold py-4 rounded-lg hover:bg-white/20 transition-all"
                >
                  上一步
                </button>
                <button 
                  onClick={handleSubmit}
                  disabled={loading}
                  className="flex-[2] bg-primary text-background-dark font-bold py-4 rounded-lg hover:brightness-110 transition-all flex items-center justify-center gap-2"
                >
                  {loading ? <span className="animate-spin material-symbols-outlined">refresh</span> : '送出訂單'}
                </button>
              </div>
            )}
          </div>
        )}
      </div>
    </>
  );
};

export default CartDrawer;
