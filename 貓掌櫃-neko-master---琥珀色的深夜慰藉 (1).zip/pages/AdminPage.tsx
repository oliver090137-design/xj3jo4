
import React, { useState } from 'react';
import { useStore, Product } from '../context/StoreContext';
import { Page } from '../App';

interface AdminPageProps {
  onNavigate: (page: Page) => void;
}

const AdminPage: React.FC<AdminPageProps> = ({ onNavigate }) => {
  const { products, addProduct, updateProduct, deleteProduct } = useStore();
  const [isEditing, setIsEditing] = useState<string | null>(null);
  const [isAdding, setIsAdding] = useState(false);

  // Form State
  const [formData, setFormData] = useState<Partial<Product>>({
    title: '',
    price: 0,
    rating: 5,
    image: '',
    description: '',
    tag: '',
    category: 'classic'
  });

  const resetForm = () => {
    setFormData({
      title: '',
      price: 0,
      rating: 5,
      image: '',
      description: '',
      tag: '',
      category: 'classic'
    });
    setIsAdding(false);
    setIsEditing(null);
  };

  const handleSave = () => {
    if (isEditing) {
      updateProduct(isEditing, formData);
    } else {
      addProduct({
        ...formData,
        id: Date.now().toString(),
        rating: 0 // Default for new
      } as Product);
    }
    resetForm();
  };

  const startEdit = (product: Product) => {
    setIsEditing(product.id);
    setFormData(product);
    setIsAdding(true);
    window.scrollTo(0, 0);
  };

  return (
    <div className="pt-24 max-w-7xl mx-auto px-6 pb-24 min-h-screen">
      <div className="flex items-center justify-between mb-8 border-b border-primary/20 pb-4">
        <h1 className="text-3xl font-calligraphy text-primary">後台管理系統</h1>
        <button onClick={() => onNavigate('home')} className="text-sm text-gray-400 hover:text-white">返回首頁</button>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Editor Form */}
        <div className={`lg:col-span-1 bg-ink-black border border-white/10 p-6 rounded-lg h-fit transition-all ${isAdding ? 'opacity-100 pointer-events-auto' : 'opacity-50 pointer-events-none lg:opacity-100 lg:pointer-events-auto'}`}>
          <h2 className="text-xl font-bold mb-6 text-white">{isEditing ? '編輯商品' : '新增商品'}</h2>
          <div className="space-y-4">
            <div>
              <label className="block text-xs text-gray-400 mb-1">商品名稱</label>
              <input 
                value={formData.title}
                onChange={e => setFormData({...formData, title: e.target.value})}
                className="w-full bg-white/5 border border-white/10 rounded px-3 py-2 text-white focus:border-primary outline-none"
              />
            </div>
            <div className="flex gap-4">
              <div className="flex-1">
                <label className="block text-xs text-gray-400 mb-1">價格 (NT$)</label>
                <input 
                  type="number"
                  value={formData.price}
                  onChange={e => setFormData({...formData, price: parseInt(e.target.value)})}
                  className="w-full bg-white/5 border border-white/10 rounded px-3 py-2 text-white focus:border-primary outline-none"
                />
              </div>
              <div className="flex-1">
                 <label className="block text-xs text-gray-400 mb-1">標籤 (選填)</label>
                <input 
                  value={formData.tag}
                  onChange={e => setFormData({...formData, tag: e.target.value})}
                  className="w-full bg-white/5 border border-white/10 rounded px-3 py-2 text-white focus:border-primary outline-none"
                />
              </div>
            </div>
            <div>
              <label className="block text-xs text-gray-400 mb-1">圖片 URL</label>
              <input 
                value={formData.image}
                onChange={e => setFormData({...formData, image: e.target.value})}
                className="w-full bg-white/5 border border-white/10 rounded px-3 py-2 text-white focus:border-primary outline-none"
              />
            </div>
             <div>
              <label className="block text-xs text-gray-400 mb-1">描述</label>
              <textarea 
                value={formData.description}
                onChange={e => setFormData({...formData, description: e.target.value})}
                rows={3}
                className="w-full bg-white/5 border border-white/10 rounded px-3 py-2 text-white focus:border-primary outline-none"
              />
            </div>
            
            <div className="flex gap-3 pt-4">
              <button 
                onClick={handleSave}
                className="flex-1 bg-primary text-background-dark font-bold py-2 rounded hover:brightness-110"
              >
                {isEditing ? '儲存變更' : '新增商品'}
              </button>
              {isEditing && (
                <button 
                  onClick={resetForm}
                  className="px-4 border border-white/20 rounded hover:bg-white/5"
                >
                  取消
                </button>
              )}
            </div>
          </div>
        </div>

        {/* Product List */}
        <div className="lg:col-span-2 space-y-4">
           <div className="flex justify-between items-center mb-4">
            <h2 className="text-xl font-bold">商品列表 ({products.length})</h2>
            <button 
              onClick={() => { resetForm(); setIsAdding(true); }}
              className="lg:hidden bg-primary text-background-dark px-4 py-1 rounded text-sm font-bold"
            >
              + 新增
            </button>
           </div>
           
           <div className="grid gap-4">
             {products.map(product => (
               <div key={product.id} className="bg-[#1a1612] border border-white/5 p-4 rounded-lg flex items-center gap-4 group hover:border-primary/30 transition-all">
                 <div className="size-16 rounded bg-white/5 overflow-hidden shrink-0">
                   <img src={product.image} className="w-full h-full object-cover" alt={product.title} />
                 </div>
                 <div className="flex-1 min-w-0">
                   <h3 className="font-bold text-white truncate">{product.title}</h3>
                   <p className="text-primary text-sm">NT$ {product.price}</p>
                 </div>
                 <div className="flex gap-2">
                   <button 
                     onClick={() => startEdit(product)}
                     className="p-2 hover:bg-white/10 rounded text-blue-400"
                   >
                     <span className="material-symbols-outlined text-lg">edit</span>
                   </button>
                   <button 
                     onClick={() => {
                        if(confirm('確定要刪除此商品嗎？')) deleteProduct(product.id);
                     }}
                     className="p-2 hover:bg-white/10 rounded text-red-400"
                   >
                     <span className="material-symbols-outlined text-lg">delete</span>
                   </button>
                 </div>
               </div>
             ))}
           </div>
        </div>
      </div>
    </div>
  );
};

export default AdminPage;
