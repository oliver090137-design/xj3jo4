
import React, { useState } from 'react';
import { Page } from '../App';

interface LivePageProps {
  onNavigate: (page: Page, productId?: string) => void;
}

const LivePage: React.FC<LivePageProps> = () => {
  const [messages, setMessages] = useState([
    { user: 'Diner_San_99', text: '這鴨翅的成色也太美了吧！', type: 'user' },
    { user: '職人貓掌櫃', text: '秘訣在於我們自家釀造的小量生產黑豆醬油。', type: 'host' },
    { user: 'Tofu_Lover_Tokyo', text: '請問下一波什麼時候可以下單？', type: 'user' },
  ]);
  const [input, setInput] = useState('');
  const [tiktokUrl, setTiktokUrl] = useState('');
  const [embedId, setEmbedId] = useState<string | null>(null);

  const sendMessage = () => {
    if (!input.trim()) return;
    setMessages([...messages, { user: 'Guest_User', text: input, type: 'user' }]);
    setInput('');
  };
  
  const handleLoadTikTok = () => {
    // Simple parser for video ID from URL (approximate)
    // Example: https://www.tiktok.com/@user/video/1234567890
    const match = tiktokUrl.match(/video\/(\d+)/);
    if (match && match[1]) {
      setEmbedId(match[1]);
    } else {
        // Fallback for demo if URL parsing fails or simple ID provided
        setEmbedId(tiktokUrl);
    }
  };

  return (
    <div className="pt-24 max-w-[1440px] mx-auto px-6 pb-24 space-y-12">
      <section className="grid grid-cols-1 lg:grid-cols-4 gap-6 h-auto lg:h-[700px]">
        {/* Stream Area (TikTok) */}
        <div className="lg:col-span-3 relative bg-black rounded-xl overflow-hidden shadow-2xl border border-white/5 flex flex-col">
            {embedId ? (
                <div className="flex-1 w-full h-full flex items-center justify-center bg-black">
                     <iframe 
                        className="w-full h-full"
                        src={`https://www.tiktok.com/embed/v2/${embedId}`}
                        allow="encrypted-media;"
                     ></iframe>
                </div>
            ) : (
                <div className="flex-1 relative group">
                    <img 
                        alt="Live Stream Placeholder" 
                        className="w-full h-full object-cover opacity-60" 
                        src="https://lh3.googleusercontent.com/aida-public/AB6AXuCxoMa_SQPeCRtweJCyttwYCasH4NK3wH6Ibu5dbH2OwxqA-Efe7txW0_bNp3RIySe0I8wkfabk-VPG4bVQVRtMfyAy6PKP_cbYpA2x2YpBtZJG9UgAMkjoBpJodqtXxcaJP23MOgrsztpQcg76qb-QTxWIDpM9S4t0XVW3jwqoZTLrxV-KHP1sPfXzgqYw7CCbowzQ8W4QaolULO2vSUm1B56zR7j30fe_eGrkY4VY6lxfVnC4-qiCh3LDYsr8UFO6RcyFRPjd9rY" 
                    />
                    <div className="absolute inset-0 flex flex-col items-center justify-center p-6 bg-black/40">
                         <div className="bg-black/80 p-6 rounded-lg max-w-md w-full border border-white/20">
                             <h3 className="text-xl font-bold mb-4 flex items-center gap-2">
                                <span className="material-symbols-outlined text-pink-500">music_note</span>
                                串接 TikTok 直播
                             </h3>
                             <p className="text-sm text-gray-400 mb-4">輸入 TikTok 影片 ID 或 URL (例如: 7291...) 即可將畫面同步至此。</p>
                             <div className="flex gap-2">
                                 <input 
                                    className="flex-1 bg-white/10 border border-white/20 rounded px-3 py-2 text-sm text-white focus:border-primary outline-none"
                                    placeholder="輸入 TikTok ID"
                                    value={tiktokUrl}
                                    onChange={(e) => setTiktokUrl(e.target.value)}
                                 />
                                 <button 
                                    onClick={handleLoadTikTok}
                                    className="bg-pink-600 text-white px-4 py-2 rounded text-sm font-bold hover:bg-pink-700"
                                 >
                                    載入
                                 </button>
                             </div>
                         </div>
                    </div>
                </div>
            )}
            
            {/* Overlay Info (Only shown if simulated or customized) */}
            <div className="absolute top-6 left-6 flex items-center gap-3 pointer-events-none">
                <span className="bg-red-600 text-white text-[11px] font-bold px-2 py-1 rounded flex items-center gap-1 tracking-wider animate-pulse">
                <span className="size-1.5 bg-white rounded-full"></span> 🔴 LIVE
                </span>
            </div>
        </div>

        {/* Chat Area */}
        <div className="flex flex-col bg-background-dark border border-white/10 rounded-xl overflow-hidden h-[500px] lg:h-full">
          <div className="p-4 border-b border-white/10 flex justify-between items-center bg-white/5">
            <h3 className="font-bold text-sm tracking-wide flex items-center gap-2">
              <span className="material-symbols-outlined text-primary text-sm">forum</span> 即時互動
            </h3>
            <span className="material-symbols-outlined text-white/40 text-sm cursor-pointer">settings</span>
          </div>
          <div className="flex-1 overflow-y-auto p-4 space-y-4">
            {messages.map((m, i) => (
              <div key={i} className={`flex flex-col ${m.type === 'host' ? 'items-end' : 'items-start'}`}>
                <span className={`text-[10px] font-bold mb-1 uppercase ${m.type === 'host' ? 'text-primary flex items-center gap-1' : 'text-white/40'}`}>
                  {m.type === 'host' && <span className="material-symbols-outlined text-[12px]">verified</span>}
                  {m.user}
                </span>
                <p className={`text-sm rounded-lg p-2 border ${m.type === 'host' ? 'bg-primary/10 border-primary text-primary' : 'bg-white/5 border-white/20 text-white'}`}>
                  {m.text}
                </p>
              </div>
            ))}
          </div>
          <div className="p-4 bg-white/5 border-t border-white/10">
            <div className="relative">
              <input 
                className="w-full bg-white/5 border border-white/10 rounded-lg py-2 pl-3 pr-10 text-sm focus:border-primary focus:ring-0 text-white" 
                placeholder="發送訊息..." 
                type="text" 
                value={input}
                onChange={(e) => setInput(e.target.value)}
                onKeyPress={(e) => e.key === 'Enter' && sendMessage()}
              />
              <button 
                onClick={sendMessage}
                className="absolute right-2 top-1/2 -translate-y-1/2 text-primary hover:scale-110 transition-transform"
              >
                <span className="material-symbols-outlined">send</span>
              </button>
            </div>
          </div>
        </div>
      </section>

      {/* Recommended Products */}
      <section className="space-y-6">
        <h3 className="text-2xl font-normal border-b border-primary/20 pb-2 font-calligraphy text-primary tracking-widest">直播推薦商品</h3>
        <div className="flex gap-4 overflow-x-auto pb-4 scrollbar-hide">
          <LiveProduct 
            name="招牌琥珀鴨翅" 
            price="480" 
            img="https://picsum.photos/200/200?random=21" 
            desc="12入分享包 • 經典香辣" 
          />
          <LiveProduct 
            name="極上絲綢滷豆腐" 
            price="220" 
            img="https://picsum.photos/200/200?random=22" 
            desc="500g 盒裝 • 鮮甜入味" 
          />
          <LiveProduct 
            name="職人手切牛腱心" 
            price="650" 
            img="https://picsum.photos/200/200?random=23" 
            desc="手工厚切 • 限量供應" 
          />
        </div>
      </section>
    </div>
  );
};

const LiveProduct: React.FC<{ name: string; price: string; img: string; desc: string }> = ({ name, price, img, desc }) => (
  <div className="min-w-[300px] bg-[#1a1612] border border-white/5 rounded-xl overflow-hidden p-3 flex gap-4 hover:border-primary/50 transition-all group">
    <div className="size-24 rounded-lg overflow-hidden bg-white/5 shrink-0">
      <img alt={name} className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500" src={img} />
    </div>
    <div className="flex flex-col justify-between flex-1 py-1">
      <div>
        <h4 className="text-sm font-bold truncate">{name}</h4>
        <p className="text-[11px] text-white/40">{desc}</p>
      </div>
      <div className="flex items-center justify-between mt-2">
        <span className="text-primary font-bold text-sm">NT$ {price}</span>
        <button className="font-calligraphy bg-primary text-background-dark text-lg px-4 py-0.5 rounded-sm hover:brightness-110 transition-all shadow-[2px_2px_0_rgba(0,0,0,0.5)]">
          立即下單
        </button>
      </div>
    </div>
  </div>
);

export default LivePage;
