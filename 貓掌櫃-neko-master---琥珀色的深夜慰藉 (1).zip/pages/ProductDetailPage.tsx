
import React, { useState, useEffect } from 'react';
import { useStore } from '../context/StoreContext';
import { Page } from '../App';

interface ProductDetailPageProps {
  onNavigate: (page: Page, productId?: string) => void;
  productId: string | null;
}

const ProductDetailPage: React.FC<ProductDetailPageProps> = ({ onNavigate, productId }) => {
  const { products, addToCart } = useStore();
  const [selectedSize, setSelectedSize] = useState('single');
  const [quantity, setQuantity] = useState(1);
  const [isAnimating, setIsAnimating] = useState(false);

  // Find product by ID or default to first
  const product = products.find(p => p.id === productId) || products[0];

  useEffect(() => {
    // Reset state when product changes
    setQuantity(1);
    setSelectedSize('single');
  }, [product]);

  if (!product) return <div>Loading...</div>;

  const handleAddToCart = () => {
    addToCart({
      productId: product.id,
      title: product.title,
      price: product.price,
      image: product.image,
      size: selectedSize,
      quantity: quantity
    });
    
    // Animation trigger
    setIsAnimating(true);
    setTimeout(() => setIsAnimating(false), 500);
  };

  return (
    <div className="pt-24 max-w-7xl mx-auto px-6 pb-24">
      <nav className="flex items-center gap-2 text-sm text-slate-400 mb-8 font-serif">
        <button onClick={() => onNavigate('home')} className="hover:text-primary transition-colors">首頁</button>
        <span className="material-symbols-outlined text-xs">chevron_right</span>
        <button onClick={() => onNavigate('home')} className="hover:text-primary transition-colors">精選菜單</button>
        <span className="material-symbols-outlined text-xs">chevron_right</span>
        <span className="text-slate-200">{product.title}</span>
      </nav>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-12">
        {/* Gallery */}
        <div className="lg:col-span-7 space-y-4">
          <div className="relative group aspect-[4/5] rounded-xl overflow-hidden bg-slate-800 shadow-2xl">
            <img 
              alt={product.title} 
              className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-700" 
              src={product.image} 
            />
          </div>
        </div>

        {/* Content */}
        <div className="lg:col-span-5 flex flex-col">
          <div className="flex items-center gap-4 mb-4">
             {product.tag && (
                <div className="border-2 border-[#b22222] text-[#b22222] px-2 py-0.5 rounded-sm font-black text-xs rotate-[-3deg] shadow-inner bg-[#b22222]/5">
                🔥 {product.tag}
                </div>
             )}
            <div className="flex items-center gap-1 text-primary">
              {[...Array(5)].map((_, i) => (
                <span key={i} className="material-symbols-outlined text-sm fill-1">star</span>
              ))}
              <span className="text-slate-300 text-xs font-medium ml-1">4.9 ({product.rating} 則評價)</span>
            </div>
          </div>

          <h1 className="text-5xl lg:text-7xl font-calligraphy mb-4 leading-tight text-white drop-shadow-[0_2px_10px_rgba(213,167,118,0.2)]">{product.title}</h1>
          <p className="text-slate-400 text-lg mb-6 leading-relaxed border-l-2 border-primary/30 pl-4 italic font-serif">
            {product.description}
          </p>

          <div className="flex items-baseline gap-3 mb-8">
            <span className="text-3xl font-bold text-white">NT$ {product.price} <span className="text-lg font-normal text-slate-400">/ 份</span></span>
          </div>

          <div className="space-y-6 mb-10">
            <div>
              <h3 className="text-sm font-semibold tracking-widest text-slate-400 mb-4 uppercase">選擇包裝規格</h3>
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                {[
                  { id: 'single', name: '單包裝', desc: '標準份量' },
                  { id: 'family', name: '家庭包 (3入)', desc: '省 10%' },
                  { id: 'bulk', name: '囤貨包 (5入)', desc: '省 15%' },
                ].map(size => (
                  <button 
                    key={size.id}
                    onClick={() => setSelectedSize(size.id)}
                    className={`p-4 border rounded-xl bg-white/5 transition-all text-left ${selectedSize === size.id ? 'border-primary bg-primary/10' : 'border-white/10 hover:bg-white/10'}`}
                  >
                    <div className="text-sm font-bold mb-1">{size.name}</div>
                    <div className={`text-xs ${selectedSize === size.id ? 'text-primary font-medium' : 'text-slate-400'}`}>{size.desc}</div>
                  </button>
                ))}
              </div>
            </div>

            <div className="flex items-center gap-6">
              <div className="space-y-2">
                <h3 className="text-xs font-semibold tracking-widest text-slate-400 uppercase">數量</h3>
                <div className="flex items-center border border-white/10 rounded-lg bg-white/5 h-12">
                  <button 
                    onClick={() => setQuantity(Math.max(1, quantity - 1))}
                    className="w-12 h-full flex items-center justify-center hover:text-primary transition-colors"
                  >
                    <span className="material-symbols-outlined text-sm">remove</span>
                  </button>
                  <span className="w-10 text-center font-bold">{quantity}</span>
                  <button 
                    onClick={() => setQuantity(quantity + 1)}
                    className="w-12 h-full flex items-center justify-center hover:text-primary transition-colors"
                  >
                    <span className="material-symbols-outlined text-sm">add</span>
                  </button>
                </div>
              </div>
              <div className="flex-1 space-y-2 pt-6">
                <button 
                  onClick={handleAddToCart}
                  className={`w-full bg-primary hover:bg-primary/90 text-background-dark h-14 rounded-lg shadow-xl transition-all flex items-center justify-center gap-3 ${isAnimating ? 'scale-95' : ''}`}
                >
                  <span className="material-symbols-outlined text-xl">shopping_cart</span>
                  <span className="font-calligraphy text-2xl tracking-widest pt-1">加入購物車</span>
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>
      
      {/* Recommended Section */}
      <section className="mt-24">
        <div className="flex items-center justify-between mb-8 border-b border-white/5 pb-4">
          <h2 className="text-2xl font-serif flex items-center gap-3">
            <span className="w-1.5 h-6 bg-primary rounded-full"></span>
            掌櫃推薦搭配
          </h2>
        </div>
        <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
          {products.slice(0, 4).map(p => (
             <RecommendedItem key={p.id} title={p.title} price={p.price.toString()} img={p.image} onClick={() => onNavigate('detail', p.id)}/>
          ))}
        </div>
      </section>
    </div>
  );
};

const RecommendedItem: React.FC<{ title: string; price: string; img: string; onClick: () => void }> = ({ title, price, img, onClick }) => (
  <div className="group cursor-pointer" onClick={onClick}>
    <div className="aspect-[3/4] rounded-xl overflow-hidden bg-slate-800 mb-4 relative">
      <img alt={title} className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500" src={img} />
      <div className="absolute inset-0 bg-black/20 group-hover:bg-black/0 transition-all"></div>
    </div>
    <h3 className="font-bold text-sm mb-1 group-hover:text-primary transition-colors font-serif">{title}</h3>
    <p className="text-primary text-sm font-bold">NT${price}</p>
  </div>
);

export default ProductDetailPage;
